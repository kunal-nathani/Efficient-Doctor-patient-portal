<?php include 'header.php';?>
<link rel="stylesheet" type="text/css" href="css/apptmain.css">
<form action="appointmentbackup.php" method="post">

<!--div class="p">
<h3 align="center" >My Appointments</h3>
<table id="Pasttable">
<tr>
<th>Doctor's name</th>
<th>Appointment Date</th>
<th>Appointment Time</th>
<th>Cancellation</th>
</tr>-->		
<form method="post" action="appointmentbackup.php">
		<table id="Pasttable">
							<tr>
								<th>Doctor's name</th>
								<th>Appointment Date</th>
								<th>Appointment Time</th>
								<th>Cost</th>
								<th>Cancellation</th>
							</tr>
						
	
</table>
</form>	
<div class="a">
	<button class="button" type="submit" value="next">Book Appointment</button>
</div>
</div>
<div class="footer">
  <ul>
    <li><a href="contact.html">Contactus</a></li>
    <li><a href="feedback.html">Feedback</a></li>
</ul>
</div>
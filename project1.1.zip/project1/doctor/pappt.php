<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="css/a.css">
<div class="main_box">
<h2><u>My Appointments</u></h2>
<table id="new">
      <tr>
                <th>Patients's name</th>
                <th>Appointment Date</th>
                <th>Appointment Time</th>
                <th>Add Cost</th>
              </tr>

           <tr>
                <th>a</th>
                <th>19/04/1003</th>
                <th>2</th>   
                <th>
           <?php
              echo'<a href="cost.php">$variable</a>';
             ?> 
              </th>
               
                  

            </tr>
            <tr>
              <th>ads</th>
            </tr>
</table>
</div>
<?php include('footer.php'); ?>
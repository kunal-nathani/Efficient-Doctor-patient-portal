<?php include('header.php'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/homepage.css">
<div class="para">
 
 <u> <h3>Organization working</h3></u>
  <center><img src="images/children.png"></center>
  <p>We here propose a doctor patient handling, managing system that helps doctors in their work and also
patients to book doctor appointments and view medical progress. The system allows doctors to manage
their booking slots online. Patients are allowed to book empty slots online and those slots are reserved in
their name. The system manages the appointment data for multiple doctors for various date and times.
Each time a user visits a doctor his/her medical entry is stored in the database by doctor. Next time a user
logs in he may view his/her entire medical history as and when needed. At the same time a doctor may
view patients medical history even bore the patient visits him. This allows for an automated patient doctor
handling system through an online interface. Our system also consists of organ donor module. This
module allows for organ donation registration as well as organ search. The module is designed to help
urgent organ requirements through easy/instant searches.
  </p>
</div>

<div class="footer">
  <ul>
    <li><a href="contact.php">Contactus</a></li>
    <li><a href="feedback.php">Feedback</a></li>
</ul>
</div>
</body>
</html>

<div class="footer">
  <ul>
    <li><a href="contact.html">Contactus</a></li>
    <li><a href="feedback.html">Feedback</a></li>
</ul>
</div>
<style type="text/css">
	.footer{
  text-align-last: right;
   margin-top: 100px;
   padding: 15px;
   background: #008080;

}
.footer ul{
  list-style-type: none;
}
.footer ul li{
  display: inline-block;
  
}
.footer ul li a{
color: white;
}

</style>
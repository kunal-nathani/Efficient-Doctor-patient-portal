 <html>
<head>
<Title>Efficient portal</Title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/homepage1.css">
<script src="js/new.js"></script>
</head>
<body>
  <div class="new">
  <div class="img1" align="left"><image src="images/logo.jpg"></div>
  <a href="login.html">Login</a><a href="registration.html">Signup</a>                
<h2>DOCTOR PATIENT PORTAL</h2>
</div>
<div id="sidebar">
<div class="toggle-btn" onclick="togglesidebar()">
  <span></span>
  <span></span>
  <span></span>
  </div>
  <ul>
  <li><a href="homepage2.php">Home</a></li>
  <li><a href="choose.html">Login page</a></li>
  <li><a href="registration.php">Registration</a></li>
  <li><a href="history.php">History</a></li>
  <li><a href="#">Appointment</a></li>
  <li><a href="organdonationl.php">Organ Donation</a></li>
  <li><a href="feedback.php">Feedback</a></li>
</ul>
</div>
  <style type="text/css">
  body{
    position: sticky;
    background-image: url("lol4.jpg");
    background-repeat: no-repeat;
    background-size: cover;
  } 
  </style>

<div class="para">
 
 <u> <h3>Organization working</h3></u>
  <center><img src="images/children.png"></center>
  <p>We here propose a doctor patient handling, managing system that helps doctors in their work and also
patients to book doctor appointments and view medical progress. The system allows doctors to manage
their booking slots online. Patients are allowed to book empty slots online and those slots are reserved in
their name. The system manages the appointment data for multiple doctors for various date and times.
Each time a user visits a doctor his/her medical entry is stored in the database by doctor. Next time a user
logs in he may view his/her entire medical history as and when needed. At the same time a doctor may
view patients medical history even bore the patient visits him. This allows for an automated patient doctor
handling system through an online interface. Our system also consists of organ donor module. This
module allows for organ donation registration as well as organ search. The module is designed to help
urgent organ requirements through easy/instant searches.
  </p>
</div>

<div class="footer">
  <ul>
    <li><a href="contact.html">Contactus</a></li>
    <li><a href="feedback.html">Feedback</a></li>
</ul>
</div>
</body>
</html>

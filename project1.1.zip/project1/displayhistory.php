<?php include('header.php'); ?>

  <style type="text/css">
    .new{
      margin-top: -150px;
    }
    #sidebar{
      margin-top: -65px;
    }

    #Pasttable{
      margin-top: 150px;
      margin-left:100px; 
       font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
       background-color: #87CEEB;
       border:2px solid black;
    }
    

#Pasttable td, #Pasttable th {
  border: 1px solid #ddd;
  padding: 8px;
}

#Pasttable tr:nth-child(even){background-color: #ADD8E6;}

#Pasttable tr:hover {background-color: #ddd;}

#Pasttable th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color:#87CEEB;
  color: white;
}
  </style>

<table style="width:80%" id="Pasttable">
  <tr>
    <th>Serial number</th>
    <th>Doctor name</th>
    <th>Date</th>
    <th>Time</th>
    <th>Report</th>
    
  </tr>
  <tr>
    <th> rahul</th>
    <th>roy</th>

 </tr>
  <tr>
   <th>raju</th>
   <th>rani</th>
  </tr>
</table>
<?php include('footer.php'); ?>

</body>
</html>

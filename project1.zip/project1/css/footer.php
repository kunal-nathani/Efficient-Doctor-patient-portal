v>
<style type="text/css">
	.footer{
    top
}
.footer ul{
  list-style-type: none;
}
.footer ul li{
  display: inline-block;
  
}
.footer ul li a{
color: white;
}

</style>
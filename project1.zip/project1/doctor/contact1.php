<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="css/contact.css">

<div class="container">
  <form action="dhomepage.php">
    <h3>Contact Us:</h3>

   
    <label for="subject">Your issue has been reported. Thankyou!</label>
    

    <a href="dhomepage.php"><input type="submit" value="Go to homepage"></a>

  </form>
	</div>
</div>
</header>	



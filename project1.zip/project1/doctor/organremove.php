<?php
include 'connect.php';


if (isset($_REQUEST['submit'])) {
  $sqll = "DELETE FROM organ WHERE organ_id={$_REQUEST["id"]} ";
  if (mysqli_query($conn,$sqll)) {
     header('Location: organ.php');
  }
  else {
      echo "appointment cannot be cancelled"; 
    }

}
?>
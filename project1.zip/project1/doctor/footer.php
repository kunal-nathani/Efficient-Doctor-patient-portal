<div class="footer">
  <ul>
    <li><a href="dcontactus.php">Contactus</a></li>
    <li><a href="dfeedback.php">Feedback</a></li>
</ul>
</div>
<style type="text/css">
	.footer{
    position: fixed;

    bottom: 0;
  text-align-last: right;
   padding: 10px;
   width: 100%;
   background: #008080;

}
.footer ul{
  list-style-type: none;
}
.footer ul li{
  display: inline-block;
  
}
.footer ul li a{
color: white;
}

</style>
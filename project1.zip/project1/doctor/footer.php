<div class="footer">
  <ul>
    <li><a href="contactus.php">Contactus</a></li>
    <li><a href="feedback.php">Feedback</a></li>
</ul>
</div>
<style type="text/css">
	.footer{
  text-align-last: right;
   margin-top: 150px;
   padding: 15px;
   background: #008080;

}
.footer ul{
  list-style-type: none;
}
.footer ul li{
  display: inline-block;
  
}
.footer ul li a{
color: white;
}

</style>
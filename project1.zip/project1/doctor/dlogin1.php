<?php
session_start();
 $con= mysqli_connect("localhost","root","");
 $db= mysqli_select_db($con,'project1');

 if(isset($_POST['email'])){
  $email=$_POST['email'];}
  $passwd=$_POST['passwd'];

  $sql="select * from doctor where email='".$email."' AND passwd='".$passwd."'";
  $result= mysqli_query($con,$sql);

  $num = mysqli_num_rows($result);

  if($num ==1){
    $email_pass = mysqli_fetch_assoc($result);
    $db_pass = $email_pass['passwd'];
    $_SESSION['fname']= $email_pass['fname'];
    $_SESSION['number'] = $email_pass['number1'];
    $_SESSION['email'] = $email_pass['email'];
    $_SESSION['city'] = $email_pass['city'];
    header('Location: organ.php');
    header('Location: dhomepage.php');
  }
  else{
    echo "invalid email or password";
  }
 
?>

<?php include('footer.php'); ?>

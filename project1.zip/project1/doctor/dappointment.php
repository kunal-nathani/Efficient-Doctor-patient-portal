<?php include 'header.php';?>
<link rel="stylesheet" type="text/css" href="css/apptmain.css">
<form action="appointmentbackup.php" method="post">
<style type="text/css">
    #sidebar{
        top: 0; 
    }
</style>

<table id="Pasttable">
    <tr>
    <th>Appointment ID</th>
        <th>patient's name</th>
        <th>Appointment Date</th>
        <th>Appointment Time</th>
        <th>Cancellation</th>
    </tr>
    <?php
    include 'connect.php';
    if ($conn-> connect_error) {
      die("connection failed:". $conn-> connect_error);
    }
    $email1 = $_SESSION['email'];
    $det = date("Y-m-d");
   $sql= "SELECT * FROM appointment WHERE date >= '$det' AND email like '%".$email1."%' OR doctor_email like '%".$email1."%' ORDER BY date ";
    $result= $conn-> query($sql);
    if ($result-> num_rows > 0) {
      while ($row = $result-> fetch_assoc()) {
        echo "<tr><td>". $row["id"]."</td>";
        echo "<td>". $row["name"]."</td>";
        echo "<td>". $row["date"]."</td>";
        echo "<td>". $row["time"]."</td>";
        
         echo '<td><form action="" method="POST"><input type="hidden" name="id" value=' . $row["id"] . ' ><input type="submit" class="btn btn-sm btn-danger" name="submit" value="    Delete   "></form></td></tr>';
        
      }
      echo "</table>";
    }
    
    ?>
</form>
</div>
<div class="footer">
  <ul>
    <li><a href="contactus.php">Contactus</a></li>
    <li><a href="dfeedback.php">Feedback</a></li>
</ul>
</div>
<style type="text/css">
    .new{
        top: 0;
       

    }
</style>

<?php

if (isset($_REQUEST['submit'])) {
  $sqll = "DELETE FROM appointment WHERE id={$_REQUEST["id"]} ";
  if (mysqli_query($conn,$sqll)) {
     header('Location: appointmentmainc.php');
  }
  else {
      echo "appointment cannot be cancelled"; 
    }

}
?>
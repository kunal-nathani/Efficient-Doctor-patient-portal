<?php include 'header.php';
?>
<style type="text/css">
    #sidebar{
        top:95;
        
    }
</style>
<link rel="stylesheet" type="text/css" href="../css/apptmain.css">
<form action="organdonation.php" method="post">
<div class="a">
    <button class="button" type="submit" value="next">Donate An Organ</button>
</div>
</form>

<table id="Pasttable">
    <tr>
    <th>Organ ID</th>
    <th>Organ</th>
    <th>patient's name</th>
    <th>Gender</th>
    <th>Age</th>
    <th>Blood Group</th>
    <th>patient's name</th>
    <th>patient's number</th>
      <th>patient's email</th>
    <th>Cancellation</th>
    </tr>
    <?php
    include 'connect.php';
    if ($conn-> connect_error) {
      die("connection failed:". $conn-> connect_error);
    }
    $email1 = $_SESSION['email'];
    $sql= "SELECT * FROM organ WHERE pemail like '%".$email1."%' OR demail like '%".$email1."%'";
    $result= $conn-> query($sql);
    if ($result-> num_rows > 0) {
      while ($row = $result-> fetch_assoc()) {
        echo "<tr><td>". $row["organ_id"]."</td>";
        echo "<td>". $row["organ"]."</td>";
        echo "<td>". $row["pname"]."</td>";
        echo "<td>". $row["gender"]."</td>";
        echo "<td>". $row["age"]."</td>";
        echo "<td>". $row["blood"]."</td>";
        echo "<td>". $row["pname"]."</td>";
        echo "<td>". $row["pnumber"]."</td>";
        echo "<td>". $row["pemail"]."</td>";
         echo '<td><form action="organremove.php" method="POST"><input type="hidden" name="id" value=' . $row["organ_id"] . ' ><input type="submit" class="btn btn-sm btn-danger" name="submit" value="    Delete   "></form></td></tr>';
        
      }
      echo "</table>";
    }
    
    ?>
</div>

<?php
include 'footer.php';
?>
<style type="text/css">
    #pasttable{
        margin-left: 90px;
    }
</style>
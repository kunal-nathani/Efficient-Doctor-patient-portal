<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="css/contact.css">
<div class="all" >    
<p>Contact us:<br>
Phoneno:9797979797/9769701538<br>
Email us:Portal@gmail.com</p>    
</div>

<div class="container">
  <form action="" method="post">
    <h3>Contact Us:</h3>

   
    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="Write your issue.." style="height:200px"></textarea>

    <input type="submit" value="Submit">

  </form>
	</div>
</div>
</header>	
<?php include('footer.php'); ?>


<?php
$index = 1;

if(isset($_POST['subject'])){$issue = $_POST['subject'];

$name = $_SESSION['fname'];
$email = $_SESSION['email'];
$number = $_SESSION['number'];


include 'connect.php';
     $stmt = $conn->prepare("INSERT INTO contact (name,email,number,issue)
    values(?,?,?,?)");
    echo $conn -> error;
    $stmt->bind_param("ssis", $name, $email, $number, $issue);
    $stmt ->execute();
    echo "feedback submitted successfully";
    
    header('Location: contact1.php');
     
    $stmt->close();
    $conn->close();
  }


  

 ?>
<?php include 'footer.php';?>
<script type="text/javascript">
       function myalert() {
                alert("Welcome to to our portal\n " + 
                "Thanks!for registration"); 
                header('Location: contact1.php');
            }
</script>
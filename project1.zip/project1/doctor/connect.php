<?php



$user= 'root';
$pass = '';
$db= 'project1' ;

$conn = new mysqli('localhost', $user, $pass, $db) or die("unable to connect");
  

?>

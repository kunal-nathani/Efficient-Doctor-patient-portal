<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="doctor/css/contact.css">

<div class="container">
  <form action="homepage2.php">
    <h3>FEEDBACK:</h3>

   
    <label for="subject">Your Feedback has been submitted. Thankyou!</label>
    

    <a href="homepage2.php"><input type="submit" value="Go to homepage"></a>

  </form>
  </div>
</div>
</header> 
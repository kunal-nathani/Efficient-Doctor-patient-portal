.checked {
    color: orange;
}

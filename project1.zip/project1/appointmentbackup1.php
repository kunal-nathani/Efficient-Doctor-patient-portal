<?php 
session_start();
if (isset($_POST['submit'])) {
  $doctor = $_POST['doctor'];
  $email = $_POST['doctor_email'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $problem = $_POST['problem'];
  $name1 = $_SESSION['name'];
  $email1 = $_SESSION['email'];
  $number1 = $_SESSION['number'];
  include 'connect.php';

      $stmt = $conn->prepare("INSERT INTO appointment (name,number,email,doctor,doctor_email,date,time,problem) values(?,?,?,?,?,?,?,?)");
            echo $conn -> error;
            $stmt->bind_param("sissssss", $name1, $number1, $email1, $doctor, $email, $date, $time, $problem);
            $stmt->execute();
        
            header('Location: appointmentmain.php');
            $stmt->close();
            $conn->close();

}

 ?>

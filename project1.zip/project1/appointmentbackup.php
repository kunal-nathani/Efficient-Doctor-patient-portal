
<?php include 'header.php'; ?>
<link rel="stylesheet" type="text/css" href="css/appoint.css">
<div class="appt">
   <form action="appointmentbackup1.php" method="post">
  <label for="Name of Doctor">Doctor's name</label>
  <input type="text" name="doctor" placeholder="Enter name of Doctor.."/required>
    <label for="Doctor's Email ID">Doctor's Email ID</label>
  <input type="text" name="doctor_email" placeholder="Enter Doctor's Email.."/required>

    <label for="date">Date of Appointment</label>
  <input type="date" name="date" placeholder="Enter date of Appointment.."/required>
  <label for="time">Time of Appointment</label>
<select name="time">
  <option>select a time</option>
  <option value="10AM">10AM</option>
  <option value="11AM">11AM</option>
  <option value="12AM">12AM</option>
  <option value="2PM">2PM</option>
  <option value="3PM">3PM</option>
  <option value="6PM">6PM</option>
  <option value="7PM">7PM</option>
  <option value="8PM">8PM</option>
</select>
<label for="Please list your Current Medications:">Mention your Problem</label><br>
      <textarea id="problem" name="problem" rows="4" cols="50" placeholder="Mention your Problem..">
      </textarea><br>
   <label for="submit"></label>
   <input type="submit" name="submit" value="submit">
 </form>
 </div>
<div class="footer">
  <ul>
    <li><a href="contact.php">Contactus</a></li>
    <li><a href="feedback.php">Feedback</a></li>
</ul>
</div>
</body>
</html>

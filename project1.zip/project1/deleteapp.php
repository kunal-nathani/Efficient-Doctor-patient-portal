<?php
include 'connect.php'
if (isset($_REQUEST['submit'])) {
  $query1 = "DELETE FROM appointment WHERE id= {$_REQUEST['id']}";
  if (mysqli_query($conn, $query1)) {
    echo "appointment cancelled";

  }
}
?>
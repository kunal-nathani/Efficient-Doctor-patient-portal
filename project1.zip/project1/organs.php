<?php include('header.php'); ?>
   <style type="text/css"> 
    .new{
    margin-top: -200px;
    }
    #sidebar{
      margin-top: -115px;
    }
    #Pasttable{
      margin-top: 200px;
      margin-left:100px;
      margin-bottom: 100px; 
       font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
       background-color: #87CEEB;
       border:2px solid black;
    }
    

#Pasttable td, #Pasttable th {
  border: 1px solid #ddd;
  padding: 8px;
}

#Pasttable tr:nth-child(even){background-color: #ADD8E6;}

#Pasttable tr:hover {background-color: #ddd;}

#Pasttable th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color:#87CEEB;
  color: white;
}
  </style>
<table id="Pasttable">
  <tr>
    <th>Organ ID</th>
    <th>Organ</th>
    <th>City</th>
    <th>Doctor's name</th>
    <th>Doctor's number</th>
    <th>Doctor's email</th>
    <th>patient's name</th>
    <th>Gender</th>
    <th>Age</th>
    <th>Blood Group</th>
    <th>patient's name</th>
    <th>patient's number</th>
    <th>patient's email</th>
  </tr>
  <?php
    include 'connect.php';
    if ($conn-> connect_error) {
      die("connection failed:". $conn-> connect_error);
    }
    $email1 = $_SESSION['email'];
    $sql= "SELECT * FROM organ ";
    $result= $conn-> query($sql);
    if ($result-> num_rows > 0) {
      while ($row = $result-> fetch_assoc()) {
        echo "<tr><td>". $row["organ_id"]."</td>";
        echo "<td>". $row["organ"]."</td>";
        echo "<td>". $row["city"]."</td>";
        echo "<td>". $row["dname"]."</td>";
        echo "<td>". $row["dnumber"]."</td>";
        echo "<td>". $row["demail"]."</td>";
        echo "<td>". $row["pname"]."</td>";
        echo "<td>". $row["gender"]."</td>";
        echo "<td>". $row["age"]."</td>";
        echo "<td>". $row["blood"]."</td>";
        echo "<td>". $row["pname"]."</td>";
        echo "<td>". $row["pnumber"]."</td>";
        echo "<td>". $row["pemail"]."</td></tr>";

         
        
      }
      echo "</table>";
    }
    
    $conn->close();
    ?>
</table>
<?php include('footer.php'); ?>

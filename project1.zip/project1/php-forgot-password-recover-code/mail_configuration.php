<?php
define("PROJECT_HOME","http://localhost/phpsamples/");

define("PORT", ""); // port number
define("MAIL_USERNAME", ""); // smtp usernmae
define("MAIL_PASSWORD", ""); // smtp password
define("MAIL_HOST", ""); // smtp host
define("MAILER", "smtp");

define("SENDER_NAME", "Admin");
define("SERDER_EMAIL", "admin@admin.com");
?>
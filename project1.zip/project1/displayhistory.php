<?php include('header.php'); ?>

  <style type="text/css">

    #Pasttable{
      margin-top: 200px;
      margin-left:100px; 
       font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
       background-color: #87CEEB;
       border:2px solid black;
    }
    

#Pasttable td, #Pasttable th {
  border: 1px solid #ddd;
  padding: 8px;
}

#Pasttable tr:nth-child(even){background-color: #ADD8E6;}

#Pasttable tr:hover {background-color: #ddd;}

#Pasttable th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color:#87CEEB;
  color: white;
}
  </style>

<table style="width:80%" id="Pasttable">
  <tr>
    <th>Serial number</th>
    <th>Doctor name</th>
    <th>Date</th>
    <th>Time</th>
    <th>Re</th>
    <th>To</th>
  </tr>
  <tr>
    <th> rahul</th>
    <th>roy</th>

 </tr>
  <tr>
   <th>raju</th>
   <th>rani</th>
  </tr>
</table>

<div class="footer">
  <ul>
    <li><a href="contact.html">Contactus</a></li>
    <li><a href="feedback.html">Feedback</a></li>
</ul>
</div>
</body>
</html>

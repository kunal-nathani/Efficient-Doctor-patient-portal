<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="doctor/css/contact.css">

<div class="container">
  <form action="appointmentmain.php">
    <h3>APPOINTMENT CANCELLED</h3>

   
    <label for="subject">Your appointment has been cancelled! </label>
    

    <a href="appointmentmain.php"><input type="submit" value="Go to Appointments"></a>

  </form>
	</div>
</div>
</header>	


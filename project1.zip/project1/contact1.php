<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="doctor/css/contact.css">

<div class="container">
  <form action="homepage2.php">
    <h3>Contact Us:</h3>

   
    <label for="subject">Your issue has been reported.<br>Sorry for inconvienence we will try to contact you as soon as possible. Thankyou!</label>
    

    <a href="homepage2.php"><input type="submit" value="Go to homepage"></a>

  </form>
	</div>
</div>
</header>	



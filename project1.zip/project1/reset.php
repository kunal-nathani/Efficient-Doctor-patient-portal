<html>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<title>Login Page</title>
<script src="js/new.js"></script>
</head>
<body>
  <div class="new">
  <div class="img" align="left"><image src="images/logo.jpg"></div>                
<h2>DOCTOR PATIENT PORTAL</h2>
</div>
  <header>

 <style type="text/css">
  body{
    position: sticky;
    background-image: url("images/lol4.jpg");
    background-repeat: no-repeat;
    background-size: cover;
  } 
  *{
  margin:0px;
  padding:0px;
  font-family:times new roman;
}
.new h2{
   text-shadow: 1px 1px 2px black, 0 0 25px #008080, 0 0 5px white;
}

#sidebar{
  margin-top: 85px;
  position:fixed;
  width:200px;
  height:100%;
  background:#151719;
  left:-200px;
}
#sidebar.active{
  left:0px;
  transition: 0.7s;
}
#sidebar ul li{
  color:rgba(230,230,230,0.9);
  list-style:none;
  padding:15px 10px;
  border-bottom:1px solid rgba(100,100,100,0.3);
}
#sidebar .toggle-btn{
  position:absolute;
  left:230px;
  top:20px;
}
#sidebar .toggle-btn span{
  display:block;
  width:30px;
  height:5px;
  background:#151719;
  margin:5px 0px;
}

* {
  box-sizing: border-box;
}
.new {
  position: fixed;
  background-color: #008080;
  margin-top: 0px;
  padding: 30px;
  width: 100%;
  height: auto;
  text-align: center;
  color: #ffffff ;

}
.new img
{ 
	top: 0;
	margin-top: 10px;
  position: fixed;
  width: 50px;
  height: auto;
}
form.example input[type=text] {
  float: right;
  padding: 5px;
  font-size: 17px;
  border: 1px solid black;
  width: 20%;
  background: #f1f1f1;
}
</style>
<div class="q">
	<h3>Reset Password</h3>
<form action="" method="post">
<label for="Email ID">Email ID</label><br>
<input type="text" name="email" placeholder="Enter email ID" ><br>
<label for="old password">Old Password</label><br>
<input type="text" name="opassword" placeholder="Enter Old Password" ><br>
<label for="new password">New password</label><br>
<input type="text" name="npassword1" placeholder="Enter New Password"><br>
<label for="new password">New password</label><br>
<input type="text" name="npassword2" placeholder="Re-enter New Password" ><br>
<input type="submit" name="submit">
</form>
</div>
<style type="text/css">
	*{
		margin: 0px;
		padding: 0px;
	}
        .new{
        	margin-top: -200px;
        }
        #sidebar{
        	margin-top: -115px;
        }
        .q{
			  border: 3px solid #008080;
			  background-color: #008080;
			  padding: 70px;
			  margin-top: 200px;
			  margin-left: 200px;
			  margin-right: 200px;
			  border-radius: 10px;
			  box-shadow: 10px 10px 5px grey;
			  color: white;
			}
			.q h3{
			  text-shadow: 1px 1px 2px black, 0 0 25px #008080, 0 0 5px white;
			  text-align: center;
			  margin: 3px;
			}
			input[type=text], select {
			  width:100%;
			  padding: 12px 20px;
			  margin: 8px 0;
			  display: inline-block;
			  border: 1px solid #ccc;
			  border-radius: 4px;
			  box-sizing: border-box;
			}
			input[type=submit] {
			  width: 40%;
			  background-color: #4CAF50;
			  color: white;
			  padding: 14px 20px;
			  margin: =13px 0;
			  border: none;
			  border-radius: 4px;
			  cursor: pointer;
			  margin-left:125px;
			  box-shadow: #f2f2f2;
			}

			input[type=submit]:hover {
			  background-color: #45a049;
			}
</style>
<?php include('footer.php'); ?>
<?php 
include('connect.php');

$select = "SELECT * from signup";
$query = mysqli_query($conn,$select);
$data = mysqli_fetch_assoc($query);

$oldpwd= $data['passwd'];

if (isset($_POST['submit'])) {
	$email = $_POST['email']; 
	$current = $_POST['opassword'];
	$new = $_POST['npassword1'];
	$confirm = $_POST['npassword2'];
	while ($row = $result-> fetch_assoc()) {	
		if ($current == $oldpwd) {
			if ($new == $confirm) {
				$update = "update signup set passwd = '$new' where email = '$email'";
				$query1 = mysqli_query($conn,$update);

				if($query1){
					echo "your password changed successfully";
				}
				else{
					echo "both passwords do not match";
				}
			}
		}
	}
}



?>
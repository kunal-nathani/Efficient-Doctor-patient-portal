<?php
$det = date("Y-m-d");
 echo $det;

?>